https://gist.github.com/dan-soncillan/0877586f7fab8041d94d64324945e396
